# Messenger Android XML Template

<a href='https://ko-fi.com/A811KFP' target='_blank'><img height='36' style='border:0px;height:36px;' src='https://az743702.vo.msecnd.net/cdn/kofi3.png?v=0' border='0' alt='Buy Me a Coffee at ko-fi.com' /></a>

Free android xml template for chat/messenger app.

[![IMAGE ALT TEXT HERE](http://img.youtube.com/vi/enwo6Igrr8Q/0.jpg)](http://www.youtube.com/watch?v=enwo6Igrr8Q)
