package com.uiresource.messenger.recyclerview;

/**
 * Created by Dytstudio.
 */

public class Conversation {
}
